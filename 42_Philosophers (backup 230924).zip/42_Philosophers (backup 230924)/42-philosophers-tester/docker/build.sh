#!/bin/bash

docker build -t memory-test:0.1 .