/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   philo.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rosta-c <rcosta-c@student.42porto.com>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/19 08:06:07 by rosta-c           #+#    #+#             */
/*   Updated: 2024/09/19 09:44:24 by rosta-c          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "philo.h"

//void	create_check_join(t_vars philo);
//void	detach_destroy(t_vars philo);

bool	ft_break_while(t_vars *args, int *i)
{
	pthread_mutex_lock(&args->sync);
	if (ft_now_ms() - args->philosophers[*i].last_meal
		>= (unsigned long long)args->t_2die
		|| args->how_many_r_full == args->n_philos)
	{
		if (args->max_rounds != -1 && args->how_many_r_full == args->n_philos)
		{
			args->philos_full = true;
			pthread_mutex_unlock(&args->philosophers[*i].l_fork);
			printf("Every philosopher has eaten %d times\n", args->max_rounds);
		}
		else
		{
			args->philo_dead = true;
			pthread_mutex_unlock(&args->philosophers[*i].l_fork);
			printf("%lu %d died\n",
				ft_now_ms() - args->start_time, args->philosophers[*i].philo_nbr);
		}
		pthread_mutex_unlock(&args->sync);
		return (true);
	}
	if (*i + 1 == args->n_philos)
		*i = -1;
	pthread_mutex_unlock(&args->sync);
	return (false);
}

int	main(int ac, char **av)
{
	t_vars	philo;
	int		i;
	int		nbr;

	init_philo(&philo, ac, av);
	//create_check_join(philo);
	i = 0;
	nbr = philo.n_philos;
	while (i < nbr)
	{
		pthread_create(&philo.philosophers[i].thread, NULL, philosophing, \
			&philo.philosophers[i]);
		i++;
	}
	/*while (i < nbr)
	{
		pthread_create(&philo.philosophers[i].thread, NULL, proutine, \
			&philo.philosophers[i]);
		i++;
	}*/
	i = 0;
	//while (++i < nbr && !ft_break_while(&philo, &i))
	//	i = i + 0;
	while (i++ < nbr && ft_checker_philos(&philo, &i) == false)
		i = i + 0;
	
	i = 0;
	while (i < nbr)
	{
	//	printf("\n\ne vai\n\n");
		pthread_join(philo.philosophers[i].thread, NULL);
		i++;
	}
	i = 0;
	//printf("\n\nVOU ENTRAR NO DETACH  \n\n");
	/*while (i++ < nbr)
	{
		printf("\n\ne vai %d\n\n", philo.philosophers->philo_nbr);
		pthread_detach(philo.philosophers[i].thread);
		i++;
	}
	i = 0;*/
	//printf("\n\n    DESTRRROOOYYY     \n\n");
	while (i < nbr)
	{
		pthread_mutex_destroy(&philo.philosophers[i].l_fork);
		i++;
	}
	//free(&philo.philosophers->thread);
	//free(&philo.sync);
	//free(&philo);

	exit(EXIT_SUCCESS);
}
/*
void	create_check_join(t_vars philo)
{
	int	x;

	x = 0;
		printf("\n\nAAAAAAAAAAAAAAAAAAAA-estouaqui\n\n");

	while (x < philo.n_philos)
	{
		pthread_create(&philo.philosophers[x].thread, NULL, philosophing, \
			&philo.philosophers[x]);
		x++;
	}
	x = 0;
			printf("\n\nVVVVVVVVVV-estouaqui\n\n");

	while (x++ < philo.n_philos && ft_checker_philos(&philo, &x) == true)
	{
		x = x + 0;
	}
	//while (x < philo.n_philos)
	//{
	//	if (ft_checker_philos(&philo, &x) == true)
	//		break ;
	//	x++;
	//}
	x = 0;		
	printf("\n\nZZZZZZZZZZZZ-estouaqui\n\n");

	while (x < philo.n_philos)
	{
		printf("\n\nZZZZ312832138172831783178371ZZZZZZZZ-estouaqui\n\n");
		pthread_join(philo.philosophers[x].thread, NULL);
		x++;
	}
	printf("\n\nDEEESSSSTROOYYYYYYY-estouaqui\n\n");
	detach_destroy(philo);
	printf("\n\nDEEESSSSTROOYYnDEEESSSSTROOYYYYYYYYYYYY-estouaqui\n\n");
}

void	detach_destroy(t_vars philo)
{
	int	x;

	x = 0;
	while (x < philo.n_philos)
	{
		pthread_detach(philo.philosophers[x].thread);
		x++;
	}
	x = 0;
	while (x < philo.n_philos)
	{
		pthread_mutex_destroy(&philo.philosophers[x].l_fork);
	}
}*/
