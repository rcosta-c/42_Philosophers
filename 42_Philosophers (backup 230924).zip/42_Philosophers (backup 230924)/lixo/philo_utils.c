#include "philo.h"

uint64_t	ft_now_ms(void)
{
	struct timeval	tv;

	gettimeofday(&tv, NULL);
	return (tv.tv_sec * 1000ULL + tv.tv_usec / 1000ULL);
}

static void	ft_tusleep(uint64_t milli)
{
	uint64_t	now;
	uint64_t	elapsed;

	now = ft_now_ms();
	elapsed = ft_now_ms();
	while (elapsed - now < milli)
	{
		usleep(333);
		elapsed = ft_now_ms();
	}
}

static bool	ft_write_status(t_data *philo, char *msg)
{
	pthread_mutex_lock(&philo->vars->sync);
	if (philo->vars->philo_dead || philo->vars->philos_full)
	{
		pthread_mutex_unlock(&philo->vars->sync);
		return (false);
	}
	printf("%lu %d %s\n", ft_now_ms() - philo->vars->start_time,
		philo->philo_nbr, msg);
	pthread_mutex_unlock(&philo->vars->sync);
	return (true);
}

static bool	ft_should_stop(t_data *philo)
{
	pthread_mutex_lock(&philo->vars->sync);
	if (philo->vars->philo_dead || philo->vars->philos_full)
	{
		pthread_mutex_unlock(&philo->vars->sync);
		return (true);
	}
	pthread_mutex_unlock(&philo->vars->sync);
	return (false);
}

static bool	ft_get_forks(t_data *philo)
{
	if (ft_should_stop(philo))
		return (false);
	pthread_mutex_lock(&philo->l_fork);
	if (!ft_write_status(philo, "has taken a fork"))
	{
		pthread_mutex_unlock(&philo->l_fork);
		return (false);
	}
	if (ft_should_stop(philo))
		return (false);
	pthread_mutex_lock(philo->r_fork);
	if (!ft_write_status(philo, "has taken a fork"))
	{
		pthread_mutex_unlock(&philo->l_fork);
		pthread_mutex_unlock(philo->r_fork);
		return (false);
	}
	return (true);
}

static bool	ft_sleep_think(t_data *philo)
{
	if (!ft_write_status(philo, "is sleeping"))
		return (false);
	ft_tusleep(philo->vars->t_2sleep);
	if (!ft_write_status(philo, "is thinking"))
		return (false);
	return (true);
}

void	*proutine(void *data)
{
	t_data	*philo;

	philo = (t_data *)data;
	if (!(philo->philo_nbr & 1))
		ft_tusleep(10);
	while (1)
	{
		if (!ft_get_forks(philo))
			break ;
		pthread_mutex_lock(&philo->vars->sync);//    LOOOCKK
		philo->meal_nbr++;
		philo->last_meal = ft_now_ms();
		pthread_mutex_unlock(&philo->vars->sync);//		UNLOOOCKK
		ft_write_status(philo, "is eating");
		ft_tusleep(philo->vars->t_2eat);
		pthread_mutex_lock(&philo->vars->sync);//			LOOOCKK
		if (philo->meal_nbr == philo->vars->max_rounds)
		philo->vars->how_many_r_full += (philo->vars->max_rounds != -1);
		pthread_mutex_unlock(&philo->vars->sync); //				UNLOOOCKK
		pthread_mutex_unlock(&philo->l_fork);//		UNLOOOCKK
		pthread_mutex_unlock(philo->r_fork);//		UNLOOOCKK
		if (!ft_sleep_think(philo))
			break ;
	}
	return (NULL);
}
